@echo off
title NCT_Developer_Tools_Menu_v2_Installer
setlocal EnableExtensions

set "APP_NAME=NCT_Developer_Tools_Context_Menu_v2"
set "APP_DIR=%LOCALAPPDATA%\%APP_NAME%"
set "HELPER_DIR=%APP_DIR%\helpers"
set "SOURCE_DIR=%~dp0"
set "SOURCE_HELPERS=%SOURCE_DIR%helpers"
set "LOG_DIR=%APP_DIR%\logs"
set "LOG_FILE=%LOG_DIR%\install.log"

cls
echo ============================================================
echo NCT Developer Tools Context Menu v2 - Installer
echo ============================================================
echo This installer adds a compact cascading context menu:
echo.
echo   Open Developer Tools
echo     Open Codex
echo     Open Command Prompt
echo     Open PowerShell
echo.
echo Scope: current Windows user only
echo Registry root: HKCU\Software\Classes
echo.

if not exist "%SOURCE_HELPERS%\open_codex_here.cmd" (
    echo ERROR: Helper file not found:
    echo   %SOURCE_HELPERS%\open_codex_here.cmd
    echo.
    echo Please extract the ZIP package before running this installer.
    echo Do not run the installer directly from inside the compressed ZIP view.
    echo.
    pause
    exit /b 1
)

mkdir "%HELPER_DIR%" >nul 2>&1
mkdir "%LOG_DIR%" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Cannot create application directory:
    echo   %APP_DIR%
    echo.
    pause
    exit /b 1
)

copy /y "%SOURCE_HELPERS%\*.cmd" "%HELPER_DIR%\" >nul
if errorlevel 1 (
    echo ERROR: Cannot copy helper scripts to:
    echo   %HELPER_DIR%
    echo.
    pause
    exit /b 1
)

> "%LOG_FILE%" echo NCT Developer Tools Context Menu v2 install log
>> "%LOG_FILE%" echo Date: %DATE% %TIME%
>> "%LOG_FILE%" echo APP_DIR=%APP_DIR%
>> "%LOG_FILE%" echo SOURCE_DIR=%SOURCE_DIR%

echo Cleaning old/broken menu keys first...
call :RemoveMenuKeys "Directory\shell"
call :RemoveMenuKeys "Directory\Background\shell"

echo Installing submenu for selected folders...
call :InstallCascade "Directory\shell" "Selected folder"
if errorlevel 1 goto :RegistryError

echo Installing submenu for folder background...
call :InstallCascade "Directory\Background\shell" "Folder background"
if errorlevel 1 goto :RegistryError

echo.
echo Done.
echo.
echo Test 1: Right-click directly on a folder.
echo Test 2: Open a folder, then right-click an empty area inside it.
echo.
echo Expected result:
echo   Open Developer Tools ^>
echo     Open Codex
echo     Open Command Prompt
echo     Open PowerShell
echo.
echo On Windows 11, classic registry menus may appear under "Show more options".
echo If the menu does not refresh immediately, run:
echo   restart_explorer__optional.bat
echo.
echo A log was written to:
echo   %LOG_FILE%
echo.
pause
exit /b 0

:RegistryError
echo.
echo ERROR: Registry setup failed.
echo Details were written to:
echo   %LOG_FILE%
echo.
echo Try running repair__nct_developer_tools_context_menu_v2.bat.
echo.
pause
exit /b 1

:RemoveMenuKeys
set "ROOT=%~1"
set "PARENT=HKCU\Software\Classes\%ROOT%\NCT_DeveloperTools"
set "OLD1=HKCU\Software\Classes\%ROOT%\NCT_OpenCodexHere"
set "OLD2=HKCU\Software\Classes\%ROOT%\NCT_OpenCmdHere"
set "OLD3=HKCU\Software\Classes\%ROOT%\NCT_OpenPowerShellHere"

reg delete "%PARENT%" /f >> "%LOG_FILE%" 2>&1
reg delete "%OLD1%" /f >> "%LOG_FILE%" 2>&1
reg delete "%OLD2%" /f >> "%LOG_FILE%" 2>&1
reg delete "%OLD3%" /f >> "%LOG_FILE%" 2>&1
exit /b 0

:InstallCascade
set "ROOT=%~1"
set "CONTEXT_LABEL=%~2"
set "PARENT=HKCU\Software\Classes\%ROOT%\NCT_DeveloperTools"

echo   Context: %CONTEXT_LABEL%
>> "%LOG_FILE%" echo Installing %PARENT%

rem Important design note:
rem Use SubCommands="" plus a local shell subtree.
rem This prevents Explorer from treating the parent item as a clickable command.
rem The previous ExtendedSubCommandsKey-only design can appear as a flat command on some systems.
reg add "%PARENT%" /f >> "%LOG_FILE%" 2>&1 || exit /b 1
reg delete "%PARENT%" /ve /f >> "%LOG_FILE%" 2>&1
reg add "%PARENT%" /v "MUIVerb" /t REG_SZ /d "Open Developer Tools" /f >> "%LOG_FILE%" 2>&1 || exit /b 1
reg add "%PARENT%" /v "Icon" /t REG_SZ /d "%SystemRoot%\System32\cmd.exe" /f >> "%LOG_FILE%" 2>&1 || exit /b 1
reg add "%PARENT%" /v "Position" /t REG_SZ /d "Top" /f >> "%LOG_FILE%" 2>&1 || exit /b 1
reg add "%PARENT%" /v "SubCommands" /t REG_SZ /d "" /f >> "%LOG_FILE%" 2>&1 || exit /b 1
reg delete "%PARENT%\command" /f >> "%LOG_FILE%" 2>&1
reg delete "%PARENT%\ExtendedSubCommandsKey" /f >> "%LOG_FILE%" 2>&1

call :AddSubCommand "%PARENT%" "01_OpenCodex" "Open Codex" "%HELPER_DIR%\open_codex_here.cmd" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" || exit /b 1
call :AddSubCommand "%PARENT%" "02_OpenCommandPrompt" "Open Command Prompt" "%HELPER_DIR%\open_command_prompt_here.cmd" "%SystemRoot%\System32\cmd.exe" || exit /b 1
call :AddSubCommand "%PARENT%" "03_OpenPowerShell" "Open PowerShell" "%HELPER_DIR%\open_powershell_here.cmd" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" || exit /b 1

exit /b 0

:AddSubCommand
set "PARENT_KEY=%~1"
set "SUBKEY_NAME=%~2"
set "MENU_LABEL=%~3"
set "HELPER_SCRIPT=%~4"
set "MENU_ICON=%~5"
set "SUBKEY=%PARENT_KEY%\shell\%SUBKEY_NAME%"

reg add "%SUBKEY%" /f >> "%LOG_FILE%" 2>&1 || exit /b 1
reg delete "%SUBKEY%" /ve /f >> "%LOG_FILE%" 2>&1
reg add "%SUBKEY%" /v "MUIVerb" /t REG_SZ /d "%MENU_LABEL%" /f >> "%LOG_FILE%" 2>&1 || exit /b 1
reg add "%SUBKEY%" /v "Icon" /t REG_SZ /d "%MENU_ICON%" /f >> "%LOG_FILE%" 2>&1 || exit /b 1
reg add "%SUBKEY%\command" /ve /t REG_SZ /d "\"%HELPER_SCRIPT%\" \"%%V\" \"%%1\"" /f >> "%LOG_FILE%" 2>&1 || exit /b 1
exit /b 0

@echo off
title NCT_Developer_Tools_Menu_v2_Repair
setlocal EnableExtensions

cls
echo ============================================================
echo NCT Developer Tools Context Menu v2 - Repair
echo ============================================================
echo This will uninstall old entries, reinstall the submenu, and refresh Explorer.
echo.

call "%~dp0uninstall__nct_developer_tools_context_menu_v2.bat"
call "%~dp0install__nct_developer_tools_context_menu_v2.bat"

echo.
echo Restarting Explorer is optional but useful after context-menu changes.
choice /C YN /M "Restart Explorer now"
if errorlevel 2 exit /b 0
call "%~dp0restart_explorer__optional.bat"
exit /b 0

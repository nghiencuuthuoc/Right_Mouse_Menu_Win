# Troubleshooting

## The menu still appears as a flat item

Run:

```text
repair__nct_developer_tools_context_menu_v2.bat
```

Then run:

```text
restart_explorer__optional.bat
```

## The menu does not appear

On Windows 11, check **Show more options**.

Then run:

```text
verify__nct_developer_tools_context_menu_v2.bat
```

The parent key must contain:

```text
SubCommands    REG_SZ
```

The commands must be under:

```text
...\NCT_DeveloperTools\shell\01_OpenCodex\command
...\NCT_DeveloperTools\shell\02_OpenCommandPrompt\command
...\NCT_DeveloperTools\shell\03_OpenPowerShell\command
```

## Open Codex says Codex CLI was not found

Test manually:

```text
where codex
codex --version
codex
```

If `where codex` fails, install Codex CLI or fix the PATH environment variable.

## Create a support report

Run:

```text
diagnose__nct_developer_tools_context_menu_v2.bat
```

It creates:

```text
%USERPROFILE%\Desktop\nct_context_menu_diagnosis.txt
```

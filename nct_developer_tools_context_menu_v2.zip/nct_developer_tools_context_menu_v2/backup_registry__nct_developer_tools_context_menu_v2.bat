@echo off
title NCT_Developer_Tools_Menu_v2_Registry_Backup
setlocal EnableExtensions

set "BACKUP_DIR=%~dp0registry_backup"
mkdir "%BACKUP_DIR%" >nul 2>&1

set "STAMP=%DATE:~-4%%DATE:~4,2%%DATE:~7,2%_%TIME:~0,2%%TIME:~3,2%%TIME:~6,2%"
set "STAMP=%STAMP: =0%"

echo Backing up current-user context-menu registry keys...

echo Exporting selected-folder key...
reg export "HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools" "%BACKUP_DIR%\selected_folder_%STAMP%.reg" /y >nul 2>&1

echo Exporting folder-background key...
reg export "HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools" "%BACKUP_DIR%\folder_background_%STAMP%.reg" /y >nul 2>&1

echo Done.
echo Backup folder:
echo   %BACKUP_DIR%
echo.
pause
exit /b 0

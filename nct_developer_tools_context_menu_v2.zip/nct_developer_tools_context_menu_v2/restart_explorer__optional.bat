@echo off
title NCT_Restart_Explorer_Optional
setlocal EnableExtensions

cls
echo ============================================================
echo Restart Windows Explorer
echo ============================================================
echo This closes and restarts Explorer to refresh the context menu.
echo Unsaved File Explorer navigation state may be lost.
echo.
choice /C YN /M "Continue"
if errorlevel 2 exit /b 0

taskkill /f /im explorer.exe >nul 2>&1
timeout /t 2 /nobreak >nul
start explorer.exe

echo Done.
timeout /t 2 /nobreak >nul
exit /b 0

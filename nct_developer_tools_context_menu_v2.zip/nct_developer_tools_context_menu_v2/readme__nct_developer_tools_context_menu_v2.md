# NCT Developer Tools Context Menu v2

This package adds a compact Windows Explorer right-click submenu for folders:

```text
Open Developer Tools
    Open Codex
    Open Command Prompt
    Open PowerShell
```

## Why v2 exists

The first package could show `Open Developer Tools` as a normal clickable item instead of a submenu on some systems. When clicked, Explorer could show an error like:

```text
This file does not have an app associated with it for performing this action.
```

The v2 installer fixes this by using a more compatible static-cascade layout:

```text
HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools
    MUIVerb = Open Developer Tools
    SubCommands = ""
    shell\01_OpenCodex\command
    shell\02_OpenCommandPrompt\command
    shell\03_OpenPowerShell\command

HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools
    MUIVerb = Open Developer Tools
    SubCommands = ""
    shell\01_OpenCodex\command
    shell\02_OpenCommandPrompt\command
    shell\03_OpenPowerShell\command
```

The key detail is `SubCommands=""` plus the local `shell` subtree. This tells Explorer that the parent item is a cascade menu, not a command to execute.

## Install

1. Extract the ZIP first.
2. Run:

```text
install__nct_developer_tools_context_menu_v2.bat
```

3. Right-click a folder or right-click an empty area inside a folder.
4. On Windows 11, classic registry menus may appear under **Show more options**.

## Repair

Run this if an old broken menu entry remains:

```text
repair__nct_developer_tools_context_menu_v2.bat
```

## Verify

Run:

```text
verify__nct_developer_tools_context_menu_v2.bat
```

Look for:

```text
SubCommands    REG_SZ
...\NCT_DeveloperTools\shell\01_OpenCodex\command
...\NCT_DeveloperTools\shell\02_OpenCommandPrompt\command
...\NCT_DeveloperTools\shell\03_OpenPowerShell\command
```

## Uninstall

Run:

```text
uninstall__nct_developer_tools_context_menu_v2.bat
```

Then optionally run:

```text
restart_explorer__optional.bat
```

## Codex requirement

`Open Codex` expects the command `codex` to be available in PATH. Test it manually with:

```text
where codex
codex --version
codex
```

If `codex` is not found, the menu still opens PowerShell in the selected folder and prints an installation/PATH warning.

## Files

```text
install__nct_developer_tools_context_menu_v2.bat
uninstall__nct_developer_tools_context_menu_v2.bat
repair__nct_developer_tools_context_menu_v2.bat
verify__nct_developer_tools_context_menu_v2.bat
diagnose__nct_developer_tools_context_menu_v2.bat
backup_registry__nct_developer_tools_context_menu_v2.bat
restart_explorer__optional.bat
helpers\open_codex_here.cmd
helpers\open_command_prompt_here.cmd
helpers\open_powershell_here.cmd
helpers\resolve_target_folder.cmd
readme__nct_developer_tools_context_menu_v2.md
context_pack__nct_developer_tools_context_menu_v2.md
```

## Safety

- Current-user only: `HKCU\Software\Classes`
- No administrator rights required
- No permanent system-wide HKLM changes
- Uninstaller removes both v2 keys and legacy single-command keys from the earlier package

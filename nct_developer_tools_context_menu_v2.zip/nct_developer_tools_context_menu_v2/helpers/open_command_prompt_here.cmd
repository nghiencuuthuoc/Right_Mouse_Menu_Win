@echo off
title Open_Command_Prompt_Here
setlocal EnableExtensions

call "%~dp0resolve_target_folder.cmd" %* > "%TEMP%\nct_context_target.txt"
set /p TARGET=<"%TEMP%\nct_context_target.txt"
del "%TEMP%\nct_context_target.txt" >nul 2>&1

if not defined TARGET set "TARGET=%CD%"
if not exist "%TARGET%\" set "TARGET=%CD%"

echo Opening Command Prompt in:
echo   %TARGET%
echo.
cmd.exe /d /k pushd "%TARGET%"
exit /b 0

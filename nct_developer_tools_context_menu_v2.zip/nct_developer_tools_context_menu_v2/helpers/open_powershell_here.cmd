@echo off
title Open_PowerShell_Here
setlocal EnableExtensions

call "%~dp0resolve_target_folder.cmd" %* > "%TEMP%\nct_context_target.txt"
set /p TARGET=<"%TEMP%\nct_context_target.txt"
del "%TEMP%\nct_context_target.txt" >nul 2>&1

if not defined TARGET set "TARGET=%CD%"
if not exist "%TARGET%\" set "TARGET=%CD%"

echo Opening PowerShell in:
echo   %TARGET%
echo.
powershell.exe -NoLogo -NoExit -ExecutionPolicy Bypass -Command "Set-Location -LiteralPath $args[0]" "%TARGET%"
exit /b 0

@echo off
rem Resolve the target folder passed by Windows Explorer context-menu tokens.
rem The installer passes both %%V and %%1. Their meaning differs between:
rem   Directory\shell                  = right-click directly on a folder
rem   Directory\Background\shell       = right-click empty area inside a folder
rem This script prints one valid folder path to stdout.

setlocal EnableExtensions
set "TARGET="

:LOOP
if "%~1"=="" goto DONE_ARGS
if exist "%~1\" (
    set "TARGET=%~1"
    goto FOUND
)
shift
goto LOOP

:DONE_ARGS
if not defined TARGET set "TARGET=%CD%"
if not exist "%TARGET%\" set "TARGET=%USERPROFILE%"

:FOUND
for %%I in ("%TARGET%") do set "TARGET=%%~fI"
endlocal & echo %TARGET%
exit /b 0

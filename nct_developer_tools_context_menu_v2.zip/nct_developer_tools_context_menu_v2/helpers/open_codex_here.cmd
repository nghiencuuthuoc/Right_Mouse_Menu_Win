@echo off
title Open_Codex_Here
setlocal EnableExtensions

call "%~dp0resolve_target_folder.cmd" %* > "%TEMP%\nct_context_target.txt"
set /p TARGET=<"%TEMP%\nct_context_target.txt"
del "%TEMP%\nct_context_target.txt" >nul 2>&1

if not defined TARGET set "TARGET=%CD%"
if not exist "%TARGET%\" set "TARGET=%CD%"

echo Opening Codex in:
echo   %TARGET%
echo.
powershell.exe -NoLogo -NoExit -ExecutionPolicy Bypass -Command "Set-Location -LiteralPath $args[0]; if (Get-Command codex -ErrorAction SilentlyContinue) { codex } else { Write-Host ''; Write-Host 'Codex CLI was not found in PATH.'; Write-Host ''; Write-Host 'Install Codex CLI or fix PATH, then test:'; Write-Host '  where codex'; Write-Host '  codex --version'; Write-Host ''; Write-Host 'Current folder:'; Write-Host (Get-Location).Path; Write-Host ''; }" "%TARGET%"
exit /b 0

# Context Pack: NCT Developer Tools Context Menu v2

## Goal

Create a robust Windows Explorer right-click submenu for folders:

```text
Open Developer Tools
    Open Codex
    Open Command Prompt
    Open PowerShell
```

The menu must work for two Explorer contexts:

1. Right-click directly on a selected folder.
2. Right-click the empty background area inside an opened folder.

## Problem observed in v1

The parent item `Open Developer Tools` appeared without a submenu arrow and acted like a flat executable command. Clicking it produced a Windows Shell error:

```text
This file does not have an app associated with it for performing this action.
```

Likely cause: an `ExtendedSubCommandsKey`-only tree was not interpreted as a cascade menu on the target Windows configuration. Explorer treated the parent verb as a command target instead of rendering child verbs.

## v2 design decision

Use a static cascading menu with:

```text
SubCommands = ""
```

and local child verbs under:

```text
...\NCT_DeveloperTools\shell\01_OpenCodex
...\NCT_DeveloperTools\shell\02_OpenCommandPrompt
...\NCT_DeveloperTools\shell\03_OpenPowerShell
```

This is more compatible for static local subcommands because the parent key explicitly declares itself as a cascade and the child commands live below a local `shell` subtree.

## Registry scope

Current-user only:

```text
HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools
HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools
```

Do not use HKLM unless a future requirement explicitly asks for all users/system-wide installation.

## Command target strategy

The command value passes both Explorer folder tokens:

```text
"<helper_script>" "%V" "%1"
```

`%V` and `%1` differ between `Directory\shell` and `Directory\Background\shell`, so helper scripts call `resolve_target_folder.cmd`, which picks the first valid directory argument and falls back to `%CD%` or `%USERPROFILE%`.

## File structure

```text
nct_developer_tools_context_menu_v2/
    install__nct_developer_tools_context_menu_v2.bat
    uninstall__nct_developer_tools_context_menu_v2.bat
    repair__nct_developer_tools_context_menu_v2.bat
    verify__nct_developer_tools_context_menu_v2.bat
    diagnose__nct_developer_tools_context_menu_v2.bat
    backup_registry__nct_developer_tools_context_menu_v2.bat
    restart_explorer__optional.bat
    helpers/
        resolve_target_folder.cmd
        open_codex_here.cmd
        open_command_prompt_here.cmd
        open_powershell_here.cmd
    docs/
        registry_layout_v2.txt
        troubleshooting.md
    readme__nct_developer_tools_context_menu_v2.md
    context_pack__nct_developer_tools_context_menu_v2.md
    package_manifest.txt
```

## Main logic

### Installer

1. Validates that the package was extracted and helper files exist.
2. Copies helpers to:

```text
%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu_v2\helpers
```

3. Deletes old v1/v2 keys.
4. Creates selected-folder and background-folder cascade menus.
5. Writes an install log to:

```text
%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu_v2\logs\install.log
```

### Uninstaller

Deletes:

```text
HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools
HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools
```

Also deletes legacy individual keys:

```text
NCT_OpenCodexHere
NCT_OpenCmdHere
NCT_OpenPowerShellHere
```

### Repair

Runs uninstall, install, then optionally restarts Explorer.

### Verify

Runs `reg query` on both registry trees and checks `cmd.exe`, `powershell.exe`, and `codex` availability.

### Diagnose

Creates a desktop report:

```text
%USERPROFILE%\Desktop\nct_context_menu_diagnosis.txt
```

## Maintenance notes

- Keep batch and command file messages in English.
- Avoid non-ASCII flags in shell commands.
- Keep HKCU-only as the default safety model.
- Do not set a parent `command` subkey; the parent must remain a cascade menu only.
- Preserve `SubCommands=""`; it is the compatibility fix.
- If a future Windows version requires modern Windows 11 top-level menu integration, that likely requires an IExplorerCommand/packaged extension approach rather than simple registry-only static verbs.

## Suggested future developer prompt

Update `nct_developer_tools_context_menu_v2` to add optional tools under the same submenu, while preserving the current HKCU registry design, `SubCommands=""`, local `shell` child verbs, and helper-based folder resolution. Keep all `.bat` and `.cmd` comments/messages in English. Add README, context pack, verify, diagnose, and uninstall scripts.

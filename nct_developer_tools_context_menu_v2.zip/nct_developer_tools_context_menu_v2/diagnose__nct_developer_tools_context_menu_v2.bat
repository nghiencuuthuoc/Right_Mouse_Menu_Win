@echo off
title NCT_Developer_Tools_Menu_v2_Diagnose
setlocal EnableExtensions

set "OUT=%USERPROFILE%\Desktop\nct_context_menu_diagnosis.txt"
set "APP_DIR=%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu_v2"

cls
echo ============================================================
echo NCT Developer Tools Context Menu v2 - Diagnosis
echo ============================================================
echo A report will be written to:
echo   %OUT%
echo.

> "%OUT%" echo NCT Developer Tools Context Menu v2 diagnosis
>> "%OUT%" echo Date: %DATE% %TIME%
>> "%OUT%" echo USERPROFILE=%USERPROFILE%
>> "%OUT%" echo APP_DIR=%APP_DIR%
>> "%OUT%" echo.
>> "%OUT%" echo ==== OS ====
ver >> "%OUT%"
>> "%OUT%" echo.
>> "%OUT%" echo ==== PATH CHECK ====
where cmd.exe >> "%OUT%" 2>&1
where powershell.exe >> "%OUT%" 2>&1
where pwsh.exe >> "%OUT%" 2>&1
where codex >> "%OUT%" 2>&1
>> "%OUT%" echo.
>> "%OUT%" echo ==== SELECTED FOLDER MENU REGISTRY ====
reg query "HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools" /s >> "%OUT%" 2>&1
>> "%OUT%" echo.
>> "%OUT%" echo ==== BACKGROUND MENU REGISTRY ====
reg query "HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools" /s >> "%OUT%" 2>&1
>> "%OUT%" echo.
>> "%OUT%" echo ==== HELPER FILES ====
dir /s /b "%APP_DIR%" >> "%OUT%" 2>&1

echo Done.
echo Please open this file if troubleshooting is needed:
echo   %OUT%
echo.
pause
exit /b 0

@echo off
title NCT_Developer_Tools_Menu_v2_Uninstaller
setlocal EnableExtensions

set "APP_NAME=NCT_Developer_Tools_Context_Menu_v2"
set "APP_DIR=%LOCALAPPDATA%\%APP_NAME%"

cls
echo ============================================================
echo NCT Developer Tools Context Menu v2 - Uninstaller
echo ============================================================
echo This removes the current-user context menu entries.
echo.

call :DeleteRoot "Directory\shell"
call :DeleteRoot "Directory\Background\shell"

rem Also remove legacy keys from the first package.
reg delete "HKCU\Software\Classes\Directory\shell\NCT_OpenCodexHere" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\shell\NCT_OpenCmdHere" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\shell\NCT_OpenPowerShellHere" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\Background\shell\NCT_OpenCodexHere" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\Background\shell\NCT_OpenCmdHere" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\Background\shell\NCT_OpenPowerShellHere" /f >nul 2>&1

if exist "%APP_DIR%" rmdir /s /q "%APP_DIR%"

echo Done.
echo If File Explorer still shows old items, run restart_explorer__optional.bat.
echo.
pause
exit /b 0

:DeleteRoot
set "ROOT=%~1"
reg delete "HKCU\Software\Classes\%ROOT%\NCT_DeveloperTools" /f >nul 2>&1
exit /b 0

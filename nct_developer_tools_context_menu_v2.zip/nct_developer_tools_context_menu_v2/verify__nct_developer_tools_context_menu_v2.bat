@echo off
title NCT_Developer_Tools_Menu_v2_Verify
setlocal EnableExtensions

cls
echo ============================================================
echo NCT Developer Tools Context Menu v2 - Verification
echo ============================================================
echo.

echo [1/4] Registry: selected folder menu
echo ------------------------------------------------------------
reg query "HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools" /s
echo.

echo [2/4] Registry: folder background menu
echo ------------------------------------------------------------
reg query "HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools" /s
echo.

echo [3/4] Helper scripts
echo ------------------------------------------------------------
set "APP_DIR=%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu_v2"
set "HELPER_DIR=%APP_DIR%\helpers"
dir /b "%HELPER_DIR%"
echo.

echo [4/4] Tool availability
echo ------------------------------------------------------------
where cmd.exe
where powershell.exe
where codex
if errorlevel 1 (
    echo.
    echo Codex CLI was not found in PATH. The menu will still open PowerShell,
    echo but Open Codex will show an installation/PATH warning until this is fixed.
)
echo.
echo Expected parent key value:
echo   SubCommands    REG_SZ
echo Expected subcommand path:
echo   ...\NCT_DeveloperTools\shell\01_OpenCodex\command
echo.
pause
exit /b 0

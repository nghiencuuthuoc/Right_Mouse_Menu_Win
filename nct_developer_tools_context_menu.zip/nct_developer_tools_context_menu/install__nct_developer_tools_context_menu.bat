@echo off
title NCT_Developer_Tools_Menu_Installer
setlocal EnableExtensions

set "APP_NAME=NCT_Developer_Tools_Context_Menu"
set "APP_DIR=%LOCALAPPDATA%\%APP_NAME%"
set "HELPER_DIR=%APP_DIR%\helpers"
set "SOURCE_DIR=%~dp0"
set "SOURCE_HELPERS=%SOURCE_DIR%helpers"

cls
echo ============================================================
echo NCT Developer Tools Context Menu - Installer
echo ============================================================
echo This installer adds a compact cascading context menu:
echo.
echo   Open Developer Tools
echo     Open Codex
echo     Open Command Prompt
echo     Open PowerShell
echo.
echo Scope: current Windows user only
echo Registry root: HKCU\Software\Classes
echo.

if not exist "%SOURCE_HELPERS%\open_codex_here.cmd" (
    echo ERROR: Helper file not found:
    echo   %SOURCE_HELPERS%\open_codex_here.cmd
    echo.
    echo Please extract the ZIP package before running this installer.
    echo Do not run the installer directly from inside the compressed ZIP view.
    echo.
    pause
    exit /b 1
)

mkdir "%HELPER_DIR%" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Cannot create helper directory:
    echo   %HELPER_DIR%
    echo.
    pause
    exit /b 1
)

copy /y "%SOURCE_HELPERS%\*.cmd" "%HELPER_DIR%\" >nul
if errorlevel 1 (
    echo ERROR: Cannot copy helper scripts to:
    echo   %HELPER_DIR%
    echo.
    pause
    exit /b 1
)

call :InstallCascade "Directory\shell" "Selected folder"
if errorlevel 1 goto :RegistryError

call :InstallCascade "Directory\Background\shell" "Folder background"
if errorlevel 1 goto :RegistryError

echo.
echo Done.
echo.
echo Test 1: Right-click directly on a folder.
echo Test 2: Open a folder, then right-click an empty area inside it.
echo.
echo On Windows 11, classic registry menus may appear under "Show more options".
echo If the menu does not appear immediately, run:
echo   restart_explorer__optional.bat
echo.
pause
exit /b 0

:RegistryError
echo.
echo ERROR: Registry setup failed.
echo Try closing File Explorer windows and running this installer again.
echo.
pause
exit /b 1

:InstallCascade
set "ROOT=%~1"
set "CONTEXT_LABEL=%~2"
set "PARENT=HKCU\Software\Classes\%ROOT%\NCT_DeveloperTools"

echo Installing menu for: %CONTEXT_LABEL%

reg delete "%PARENT%\ExtendedSubCommandsKey" /f >nul 2>&1

reg add "%PARENT%" /ve /d "" /f >nul || exit /b 1
reg add "%PARENT%" /v "MUIVerb" /t REG_SZ /d "Open Developer Tools" /f >nul || exit /b 1
reg add "%PARENT%" /v "Icon" /t REG_SZ /d "%SystemRoot%\System32\cmd.exe" /f >nul || exit /b 1
reg add "%PARENT%" /v "Position" /t REG_SZ /d "Top" /f >nul || exit /b 1

call :AddSubCommand "%PARENT%" "01_OpenCodex" "Open Codex" "%HELPER_DIR%\open_codex_here.cmd" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" || exit /b 1
call :AddSubCommand "%PARENT%" "02_OpenCommandPrompt" "Open Command Prompt" "%HELPER_DIR%\open_command_prompt_here.cmd" "%SystemRoot%\System32\cmd.exe" || exit /b 1
call :AddSubCommand "%PARENT%" "03_OpenPowerShell" "Open PowerShell" "%HELPER_DIR%\open_powershell_here.cmd" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" || exit /b 1

exit /b 0

:AddSubCommand
set "PARENT_KEY=%~1"
set "SUBKEY_NAME=%~2"
set "MENU_LABEL=%~3"
set "HELPER_SCRIPT=%~4"
set "MENU_ICON=%~5"
set "SUBKEY=%PARENT_KEY%\ExtendedSubCommandsKey\Shell\%SUBKEY_NAME%"

reg add "%SUBKEY%" /ve /d "" /f >nul || exit /b 1
reg add "%SUBKEY%" /v "MUIVerb" /t REG_SZ /d "%MENU_LABEL%" /f >nul || exit /b 1
reg add "%SUBKEY%" /v "Icon" /t REG_SZ /d "%MENU_ICON%" /f >nul || exit /b 1
reg add "%SUBKEY%\command" /ve /t REG_SZ /d "\"%HELPER_SCRIPT%\" \"%%1\" \"%%V\"" /f >nul || exit /b 1
exit /b 0

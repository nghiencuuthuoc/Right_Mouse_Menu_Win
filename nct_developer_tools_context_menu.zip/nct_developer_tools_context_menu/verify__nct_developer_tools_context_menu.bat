@echo off
title NCT_Developer_Tools_Menu_Verifier
setlocal EnableExtensions

set "APP_NAME=NCT_Developer_Tools_Context_Menu"
set "APP_DIR=%LOCALAPPDATA%\%APP_NAME%"
set "HELPER_DIR=%APP_DIR%\helpers"

cls
echo ============================================================
echo NCT Developer Tools Context Menu - Verification
echo ============================================================
echo.

echo [1] Helper directory
echo     %HELPER_DIR%
if exist "%HELPER_DIR%" (
    echo     OK: directory exists
) else (
    echo     MISSING: directory does not exist
)
echo.

echo [2] Helper scripts
for %%F in (open_codex_here.cmd open_command_prompt_here.cmd open_powershell_here.cmd) do (
    if exist "%HELPER_DIR%\%%F" (
        echo     OK: %%F
    ) else (
        echo     MISSING: %%F
    )
)
echo.

echo [3] Registry keys
reg query "HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools" >nul 2>&1
if errorlevel 1 (echo     MISSING: selected folder menu) else (echo     OK: selected folder menu)
reg query "HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools" >nul 2>&1
if errorlevel 1 (echo     MISSING: folder background menu) else (echo     OK: folder background menu)
echo.

echo [4] Command availability
where cmd.exe >nul 2>&1
if errorlevel 1 (echo     MISSING: cmd.exe) else (echo     OK: cmd.exe)
where powershell.exe >nul 2>&1
if errorlevel 1 (echo     MISSING: powershell.exe) else (echo     OK: powershell.exe)
where pwsh.exe >nul 2>&1
if errorlevel 1 (echo     INFO: pwsh.exe not found. Windows PowerShell will be used.) else (echo     OK: pwsh.exe)
where codex >nul 2>&1
if errorlevel 1 (
    echo     INFO: codex was not found in PATH.
    echo     The Open Codex menu will still be installed, but it will show a help message until Codex CLI is installed.
) else (
    echo     OK: codex
    codex --version
)
echo.

echo [5] Windows version
ver
echo.

echo Verification finished.
echo.
pause
exit /b 0

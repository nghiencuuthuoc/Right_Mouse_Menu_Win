@echo off
title NCT_Restart_Explorer_Optional
setlocal EnableExtensions

cls
echo ============================================================
echo Restart File Explorer - Optional
echo ============================================================
echo This will close and restart explorer.exe.
echo Open File Explorer windows may be closed.
echo.
choice /c YN /m "Continue"
if errorlevel 2 exit /b 0

taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe

echo Done.
timeout /t 2 >nul
exit /b 0

# NCT Developer Tools Context Menu

This package adds a compact Windows folder context menu:

```text
Open Developer Tools
    Open Codex
    Open Command Prompt
    Open PowerShell
```

## What it changes

The installer writes only to the current user's registry area:

```text
HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools
HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools
```

It also copies helper scripts to:

```text
%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu\helpers
```

No admin rights are required.

## Files

```text
install__nct_developer_tools_context_menu.bat       Install the submenu
uninstall__nct_developer_tools_context_menu.bat     Remove the submenu and helper files
verify__nct_developer_tools_context_menu.bat        Check registry, helper scripts, and Codex availability
backup_registry__nct_developer_tools_context_menu.bat Export current menu registry keys
restart_explorer__optional.bat                      Restart Explorer if the menu does not refresh
helpers\open_codex_here.cmd                         Open Codex in the target folder
helpers\open_command_prompt_here.cmd                Open Command Prompt in the target folder
helpers\open_powershell_here.cmd                    Open PowerShell in the target folder
helpers\resolve_target_folder.cmd                   Shared folder resolution helper for future expansion
```

## Installation

1. Extract the ZIP package first.
2. Double-click:

```text
install__nct_developer_tools_context_menu.bat
```

3. Right-click directly on a folder, or right-click an empty area inside a folder.
4. On Windows 11, classic registry context menu entries may appear under **Show more options**.

## Verification

Run:

```text
verify__nct_developer_tools_context_menu.bat
```

This checks:

- helper scripts
- selected-folder registry key
- folder-background registry key
- `cmd.exe`
- `powershell.exe`
- optional `pwsh.exe`
- optional `codex`

## Codex requirement

The menu item **Open Codex** expects the command `codex` to be available in PATH.

Test manually:

```text
where codex
codex --version
codex
```

If Codex is not installed, the menu will still open a PowerShell window and show a helpful message.

## Uninstall

Run:

```text
uninstall__nct_developer_tools_context_menu.bat
```

If File Explorer still shows stale menu items, run:

```text
restart_explorer__optional.bat
```

## Design notes

This package uses `ExtendedSubCommandsKey` to create a reusable cascading submenu under the folder context menu. It avoids HKLM and avoids all-users installation so it is safer and easier to remove.

@echo off
title Open_Codex_Here
setlocal EnableExtensions

set "TARGET=%~1"
if not defined TARGET set "TARGET=%~2"
if defined TARGET (
    if not exist "%TARGET%\" (
        if exist "%~2\" set "TARGET=%~2"
    )
)
if not defined TARGET set "TARGET=%CD%"
if not exist "%TARGET%\" set "TARGET=%CD%"

set "PS_EXE=powershell.exe"
where pwsh.exe >nul 2>&1 && set "PS_EXE=pwsh.exe"

"%PS_EXE%" -NoLogo -NoExit -ExecutionPolicy Bypass -Command "Set-Location -LiteralPath $args[0]; if (Get-Command codex -ErrorAction SilentlyContinue) { codex } else { Write-Host ''; Write-Host 'Codex CLI was not found in PATH.'; Write-Host ''; Write-Host 'Install Codex CLI or fix PATH, then test:'; Write-Host '  where codex'; Write-Host '  codex --version'; Write-Host ''; }" "%TARGET%"
exit /b 0

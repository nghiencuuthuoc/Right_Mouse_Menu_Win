@echo off
title Open_Command_Prompt_Here
setlocal EnableExtensions

set "TARGET=%~1"
if not defined TARGET set "TARGET=%~2"
if defined TARGET (
    if not exist "%TARGET%\" (
        if exist "%~2\" set "TARGET=%~2"
    )
)
if not defined TARGET set "TARGET=%CD%"
if not exist "%TARGET%\" set "TARGET=%CD%"

cmd.exe /d /k pushd "%TARGET%"
exit /b 0

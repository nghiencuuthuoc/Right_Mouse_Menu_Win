@echo off
rem This helper is intended to be called with:
rem   resolve_target_folder.cmd "%%1" "%%V"
rem It prints one resolved folder path to stdout.
setlocal EnableExtensions

set "TARGET=%~1"
if not defined TARGET set "TARGET=%~2"

if defined TARGET (
    if not exist "%TARGET%\" (
        if exist "%~2\" set "TARGET=%~2"
    )
)

if not defined TARGET set "TARGET=%CD%"
if not exist "%TARGET%\" set "TARGET=%CD%"

endlocal & echo %TARGET%
exit /b 0

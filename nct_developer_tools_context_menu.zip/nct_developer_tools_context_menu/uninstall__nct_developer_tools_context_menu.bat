@echo off
title NCT_Developer_Tools_Menu_Uninstaller
setlocal EnableExtensions

set "APP_NAME=NCT_Developer_Tools_Context_Menu"
set "APP_DIR=%LOCALAPPDATA%\%APP_NAME%"

cls
echo ============================================================
echo NCT Developer Tools Context Menu - Uninstaller
echo ============================================================
echo.

reg delete "HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools" /f >nul 2>&1

if exist "%APP_DIR%" (
    rmdir /s /q "%APP_DIR%" >nul 2>&1
)

echo Done.
echo If File Explorer still shows old items, run:
echo   restart_explorer__optional.bat
echo.
pause
exit /b 0

# Developer Context Pack: NCT Developer Tools Context Menu

## Goal

Create a safe, current-user-only Windows context menu package that adds a cascading submenu for folders:

```text
Open Developer Tools
    Open Codex
    Open Command Prompt
    Open PowerShell
```

The package targets two Explorer contexts:

1. Right-click on a selected folder.
2. Right-click in the empty background area inside a folder.

## Registry strategy

Use current-user registry keys only:

```text
HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools
HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools
```

The submenu is implemented with an `ExtendedSubCommandsKey` child key:

```text
NCT_DeveloperTools
    MUIVerb = Open Developer Tools
    Icon = C:\Windows\System32\cmd.exe
    Position = Top
    ExtendedSubCommandsKey
        Shell
            01_OpenCodex
                MUIVerb = Open Codex
                Icon = powershell.exe
                command\(Default) = "open_codex_here.cmd" "%1" "%V"
            02_OpenCommandPrompt
                MUIVerb = Open Command Prompt
                Icon = cmd.exe
                command\(Default) = "open_command_prompt_here.cmd" "%1" "%V"
            03_OpenPowerShell
                MUIVerb = Open PowerShell
                Icon = powershell.exe
                command\(Default) = "open_powershell_here.cmd" "%1" "%V"
```

Using both `%1` and `%V` improves compatibility across selected-folder and background-folder contexts. Each helper script selects the first valid folder path.

## File structure

```text
install__nct_developer_tools_context_menu.bat
uninstall__nct_developer_tools_context_menu.bat
verify__nct_developer_tools_context_menu.bat
backup_registry__nct_developer_tools_context_menu.bat
restart_explorer__optional.bat
helpers/
    open_codex_here.cmd
    open_command_prompt_here.cmd
    open_powershell_here.cmd
    resolve_target_folder.cmd
readme__nct_developer_tools_context_menu.md
context_pack__nct_developer_tools_context_menu.md
```

## Runtime behavior

### Open Command Prompt

Runs:

```text
cmd.exe /d /k pushd "<target>"
```

`pushd` is used because it handles UNC paths more safely than plain `cd`.

### Open PowerShell

Prefers PowerShell 7 if `pwsh.exe` exists. Falls back to Windows PowerShell:

```text
powershell.exe -NoLogo -NoExit -ExecutionPolicy Bypass -Command "Set-Location -LiteralPath $args[0]" "<target>"
```

### Open Codex

Also prefers `pwsh.exe`, then falls back to `powershell.exe`. It changes to the target folder and checks `Get-Command codex` before launching Codex. If missing, it prints setup diagnostics instead of silently failing.

## Input and output

Input:

- Explorer-selected folder path via `%1` or `%V`.
- Explorer background folder path via `%V` or `%1`, depending on shell context behavior.

Output:

- Registry keys under HKCU.
- Helper scripts copied to `%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu\helpers`.

## Maintenance notes

- Keep batch file messages and comments in English.
- Avoid HKLM unless an explicit all-users installer is required.
- Do not require admin rights for the default installer.
- If a top-level Windows 11 modern context menu entry is required, this registry-only approach may not be enough; a packaged shell extension / IExplorerCommand approach may be needed.
- Keep uninstall idempotent: deleting missing keys must not fail visibly.
- Keep helper scripts separate so registry commands remain short and quote-safe.

## Suggested future developer prompt

Upgrade the existing `NCT Developer Tools Context Menu` package. Preserve current-user-only installation, `ExtendedSubCommandsKey`, and the current file structure. Add a configurable submenu item for Windows Terminal and VS Code, with installer switches to enable or disable optional commands. Keep all batch comments and console messages in English. Update README and this context pack after changes.

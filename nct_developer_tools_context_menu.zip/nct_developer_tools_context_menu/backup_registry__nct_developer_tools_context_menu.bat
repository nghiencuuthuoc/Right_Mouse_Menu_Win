@echo off
title NCT_Developer_Tools_Menu_Registry_Backup
setlocal EnableExtensions

set "APP_NAME=NCT_Developer_Tools_Context_Menu"
set "BACKUP_DIR=%LOCALAPPDATA%\%APP_NAME%\backups"

for /f %%I in ('powershell.exe -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "TS=%%I"
if not defined TS set "TS=backup"

mkdir "%BACKUP_DIR%" >nul 2>&1

reg export "HKCU\Software\Classes\Directory\shell\NCT_DeveloperTools" "%BACKUP_DIR%\selected_folder_%TS%.reg" /y >nul 2>&1
reg export "HKCU\Software\Classes\Directory\Background\shell\NCT_DeveloperTools" "%BACKUP_DIR%\folder_background_%TS%.reg" /y >nul 2>&1

echo Backup folder:
echo   %BACKUP_DIR%
echo.
echo Note: If a key did not exist, no backup file was created for that key.
echo.
pause
exit /b 0

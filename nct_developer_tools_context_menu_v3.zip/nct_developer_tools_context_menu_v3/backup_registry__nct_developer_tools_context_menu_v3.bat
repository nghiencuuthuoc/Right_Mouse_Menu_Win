@echo off
title NCT_Developer_Tools_Context_Menu_v3_Backup_Registry
setlocal EnableExtensions

set "BACKUP_DIR=%~dp0backups"
set "STAMP=%DATE:/=-%_%TIME::=-%"
set "STAMP=%STAMP: =_%"
mkdir "%BACKUP_DIR%" >nul 2>&1

echo Exporting current registry entries...
reg export "HKCU\Software\Classes\Directory\shell\NCTDeveloperTools" "%BACKUP_DIR%\directory_shell_NCTDeveloperTools_%STAMP%.reg" /y >nul 2>&1
reg export "HKCU\Software\Classes\Directory\Background\shell\NCTDeveloperTools" "%BACKUP_DIR%\directory_background_shell_NCTDeveloperTools_%STAMP%.reg" /y >nul 2>&1

echo Backup folder:
echo   %BACKUP_DIR%
echo.
pause

@echo off
title NCT_Developer_Tools_Context_Menu_v3_Verify
setlocal EnableExtensions

set "INSTALL_DIR=%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu"

echo ============================================================
echo NCT Developer Tools Context Menu v3 - Verify
echo ============================================================
echo.

echo [1] Installed helper files
echo ------------------------------------------------------------
dir "%INSTALL_DIR%\helpers" /b 2>nul
if errorlevel 1 echo Helpers are not installed.
echo.

echo [2] Selected-folder context menu registry
echo ------------------------------------------------------------
reg query "HKCU\Software\Classes\Directory\shell\NCTDeveloperTools" /s
echo.

echo [3] Folder-background context menu registry
echo ------------------------------------------------------------
reg query "HKCU\Software\Classes\Directory\Background\shell\NCTDeveloperTools" /s
echo.

echo [4] Tool availability
echo ------------------------------------------------------------
where powershell.exe
where cmd.exe
where codex 2>nul
if errorlevel 1 (
    echo Codex CLI was not found in PATH.
    echo Open Codex will still open PowerShell in the selected folder and show install guidance.
)
echo.
pause

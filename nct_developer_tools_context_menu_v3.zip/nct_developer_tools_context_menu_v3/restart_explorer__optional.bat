@echo off
title NCT_Developer_Tools_Context_Menu_Restart_Explorer
setlocal EnableExtensions

echo This will restart Windows Explorer to refresh context menus.
echo Save any active Explorer operations before continuing.
echo.
pause

taskkill /f /im explorer.exe >nul 2>&1
timeout /t 2 /nobreak >nul
start explorer.exe

echo Explorer restarted.
echo.
pause

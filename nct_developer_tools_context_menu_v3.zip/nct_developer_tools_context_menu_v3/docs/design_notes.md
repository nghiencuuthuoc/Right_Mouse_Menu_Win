# Design Notes - NCT Developer Tools Context Menu v3

## Goals

Create a compact right-click folder submenu:

```text
Open Developer Tools
    Open Codex
    Open Command Prompt
    Open PowerShell
```

The menu must work when right-clicking:

1. Directly on a folder.
2. On empty background inside a folder.

## Why v3 uses PowerShell `-File`

v2 used inline `-Command` and `$args[0]`. On the user's machine, the folder path was appended after the inline command string and was not bound to `$args[0]`. That caused:

```text
Set-Location : Cannot bind argument to parameter 'LiteralPath' because it is null.
```

v3 uses `.ps1` wrappers with a named `-Target` parameter. This is easier to quote and safer for paths with spaces.

## Why HKCU is used

The installer writes to:

```text
HKCU\Software\Classes
```

This avoids administrator rights and limits the change to the current user.

## Why both `%V` and `%1` are passed

Explorer provides different placeholders depending on whether the verb is invoked from a selected folder or the folder background. Passing both values lets the helper script choose the valid folder path.

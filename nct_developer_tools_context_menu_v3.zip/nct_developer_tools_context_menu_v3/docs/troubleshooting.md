# Troubleshooting - NCT Developer Tools Context Menu v3

## Problem: `Set-Location -LiteralPath $args[0]` is null

This was the v2 bug. The old helper used an inline `powershell.exe -Command` string and then attempted to read `$args[0]`.
On some command lines, the selected folder was appended to the command string instead of becoming a clean PowerShell argument.

v3 fixes this by using:

```bat
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -NoExit -File "open_codex_here.ps1" -Target "<folder>"
```

The PowerShell script receives a named `$Target` parameter, then calls:

```powershell
Set-Location -LiteralPath $resolvedTarget
```

## Problem: Codex CLI was not found

Run:

```bat
where codex
codex --version
```

If `where codex` fails, install Codex CLI or add the directory containing `codex.exe` or `codex.cmd` to PATH.

## Problem: Old broken menu still appears

Run:

```bat
repair__nct_developer_tools_context_menu_v3.bat
restart_explorer__optional.bat
```

The repair script removes old v1/v2 keys and reinstalls the v3 registry layout.

## Problem: menu is not visible immediately

Restart Windows Explorer using:

```bat
restart_explorer__optional.bat
```

On Windows 11, classic registry menu items can appear under **Show more options**.

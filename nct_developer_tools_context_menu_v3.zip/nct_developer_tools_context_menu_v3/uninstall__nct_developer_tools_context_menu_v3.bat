@echo off
title NCT_Developer_Tools_Context_Menu_v3_Uninstaller
setlocal EnableExtensions

set "INSTALL_DIR=%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu"

echo ============================================================
echo NCT Developer Tools Context Menu v3 - Uninstaller
echo ============================================================
echo.

echo Removing context menu registry entries...
for %%R in ("Directory\shell" "Directory\Background\shell") do (
    reg delete "HKCU\Software\Classes\%%~R\NCTDeveloperTools" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_DeveloperTools" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCTDeveloperToolsV2" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCTDeveloperToolsV3" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCodexHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCmdHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCommandPromptHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenPowerShellHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenPowershellHere" /f >nul 2>&1
)
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\NCT.OpenCodex" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\NCT.OpenCommandPrompt" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\NCT.OpenPowerShell" /f >nul 2>&1

if exist "%INSTALL_DIR%" (
    echo Removing installed helper scripts...
    rmdir /s /q "%INSTALL_DIR%" >nul 2>&1
)

echo.
echo Uninstall completed.
echo If Explorer still shows old items, run restart_explorer__optional.bat.
echo.
pause
exit /b 0

# NCT Developer Tools Context Menu v3

This package adds a compact Windows Explorer right-click submenu for folders:

```text
Open Developer Tools
    Open Codex
    Open Command Prompt
    Open PowerShell
```

## What v3 fixes

v3 fixes the previous PowerShell argument bug where `$args[0]` could be null and the selected folder path could be interpreted as a command.

The new version uses PowerShell `.ps1` helper scripts with a named `-Target` parameter instead of inline `powershell.exe -Command` argument passing.

## Install

1. Extract this ZIP file.
2. Run:

```bat
install__nct_developer_tools_context_menu_v3.bat
```

3. Right-click a folder or empty folder background.
4. Open:

```text
Open Developer Tools
```

## Repair old broken menu

Run:

```bat
repair__nct_developer_tools_context_menu_v3.bat
```

Then run:

```bat
restart_explorer__optional.bat
```

## Uninstall

Run:

```bat
uninstall__nct_developer_tools_context_menu_v3.bat
```

## Check Codex CLI

Run:

```bat
check_codex_path__nct_developer_tools_context_menu_v3.bat
```

If `where codex` fails, install Codex CLI or add it to PATH.

## Install location

The installer copies helper scripts to:

```text
%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu\helpers
```

This means the menu continues to work even if you move or delete the extracted ZIP folder after installation.

## Registry scope

The installer writes only to:

```text
HKCU\Software\Classes
```

No administrator rights are required.

## Windows 11 note

Classic registry-based context menu items may appear under **Show more options**.

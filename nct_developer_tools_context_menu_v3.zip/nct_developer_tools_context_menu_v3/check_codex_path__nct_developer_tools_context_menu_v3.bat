@echo off
title NCT_Developer_Tools_Check_Codex_CLI
setlocal EnableExtensions

echo ============================================================
echo Codex CLI check
echo ============================================================
echo.
where codex
if errorlevel 1 (
    echo.
    echo Codex CLI was not found in PATH.
    echo Install Codex CLI or add it to PATH, then test again:
    echo   where codex
    echo   codex --version
    echo.
    pause
    exit /b 1
)

echo.
echo Running codex --version...
codex --version
echo.
pause

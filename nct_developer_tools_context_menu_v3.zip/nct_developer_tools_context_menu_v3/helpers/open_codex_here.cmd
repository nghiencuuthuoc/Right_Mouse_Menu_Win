@echo off
title Open_Codex_Here
setlocal EnableExtensions

set "TARGET=%~1"
if not defined TARGET set "TARGET=%~2"
if not defined TARGET set "TARGET=%CD%"

if exist "%TARGET%\" goto :NormalizeFolder
if exist "%TARGET%" (
    for %%I in ("%TARGET%") do set "TARGET=%%~dpI"
    goto :NormalizeFolder
)
set "TARGET=%CD%"

:NormalizeFolder
for %%I in ("%TARGET%") do set "TARGET=%%~fI"

echo Opening Codex in:
echo   %TARGET%
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0open_codex_here.ps1" -Target "%TARGET%"

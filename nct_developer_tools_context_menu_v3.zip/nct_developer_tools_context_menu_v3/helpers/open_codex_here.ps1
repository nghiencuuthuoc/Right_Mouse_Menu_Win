param(
    [Parameter(Mandatory = $false)]
    [string]$Target
)

$Host.UI.RawUI.WindowTitle = "Open Codex Here"

function Resolve-TargetFolder {
    param([string]$InputPath)

    if ([string]::IsNullOrWhiteSpace($InputPath)) {
        return (Get-Location).ProviderPath
    }

    try {
        if (Test-Path -LiteralPath $InputPath -PathType Container) {
            return (Resolve-Path -LiteralPath $InputPath).ProviderPath
        }

        if (Test-Path -LiteralPath $InputPath -PathType Leaf) {
            $resolvedFile = (Resolve-Path -LiteralPath $InputPath).ProviderPath
            return (Split-Path -LiteralPath $resolvedFile -Parent)
        }
    }
    catch {
        Write-Warning "Could not resolve target path: $InputPath"
    }

    return (Get-Location).ProviderPath
}

function Find-CodexCandidate {
    $command = Get-Command codex -ErrorAction SilentlyContinue
    if ($null -ne $command) {
        return "codex"
    }

    $candidatePaths = @(
        (Join-Path $env:APPDATA "npm\codex.cmd"),
        (Join-Path $env:USERPROFILE ".codex\bin\codex.exe"),
        (Join-Path $env:LOCALAPPDATA "Programs\Codex\codex.exe"),
        (Join-Path $env:LOCALAPPDATA "Programs\codex\codex.exe")
    )

    foreach ($candidate in $candidatePaths) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
    }

    return $null
}

$resolvedTarget = Resolve-TargetFolder -InputPath $Target
Set-Location -LiteralPath $resolvedTarget

Write-Host "Codex target folder:"
Write-Host "  $resolvedTarget"
Write-Host ""

$codexCommand = Find-CodexCandidate
if ($null -ne $codexCommand) {
    Write-Host "Starting Codex CLI..."
    Write-Host ""
    & $codexCommand
    return
}

Write-Host "Codex CLI was not found in PATH." -ForegroundColor Yellow
Write-Host ""
Write-Host "Install Codex CLI or fix PATH, then test:"
Write-Host "  where codex"
Write-Host "  codex --version"
Write-Host ""
Write-Host "Current folder is already set to:"
Write-Host "  $resolvedTarget"
Write-Host ""

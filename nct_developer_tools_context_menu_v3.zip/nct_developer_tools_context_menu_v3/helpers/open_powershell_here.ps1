param(
    [Parameter(Mandatory = $false)]
    [string]$Target
)

$Host.UI.RawUI.WindowTitle = "Open PowerShell Here"

function Resolve-TargetFolder {
    param([string]$InputPath)

    if ([string]::IsNullOrWhiteSpace($InputPath)) {
        return (Get-Location).ProviderPath
    }

    try {
        if (Test-Path -LiteralPath $InputPath -PathType Container) {
            return (Resolve-Path -LiteralPath $InputPath).ProviderPath
        }

        if (Test-Path -LiteralPath $InputPath -PathType Leaf) {
            $resolvedFile = (Resolve-Path -LiteralPath $InputPath).ProviderPath
            return (Split-Path -LiteralPath $resolvedFile -Parent)
        }
    }
    catch {
        Write-Warning "Could not resolve target path: $InputPath"
    }

    return (Get-Location).ProviderPath
}

$resolvedTarget = Resolve-TargetFolder -InputPath $Target
Set-Location -LiteralPath $resolvedTarget

Write-Host "PowerShell opened in:"
Write-Host "  $resolvedTarget"
Write-Host ""

@echo off
title NCT_Developer_Tools_Context_Menu_v3_Repair
setlocal EnableExtensions

echo ============================================================
echo NCT Developer Tools Context Menu v3 - Repair
echo ============================================================
echo.
echo This repair removes old v1/v2 broken keys and reinstalls v3.
echo.
call "%~dp0install__nct_developer_tools_context_menu_v3.bat"
exit /b %errorlevel%

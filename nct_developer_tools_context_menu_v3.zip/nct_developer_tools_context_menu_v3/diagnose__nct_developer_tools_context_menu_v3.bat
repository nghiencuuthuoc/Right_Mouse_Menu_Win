@echo off
title NCT_Developer_Tools_Context_Menu_v3_Diagnose
setlocal EnableExtensions

set "LOG_DIR=%~dp0diagnostics"
set "LOG_FILE=%LOG_DIR%\diagnose_context_menu_v3.txt"
mkdir "%LOG_DIR%" >nul 2>&1

(
    echo ============================================================
    echo NCT Developer Tools Context Menu v3 - Diagnostics
    echo Created: %DATE% %TIME%
    echo ============================================================
    echo.
    echo Current directory:
    cd
    echo.
    echo OS:
    ver
    echo.
    echo Environment:
    echo USERPROFILE=%USERPROFILE%
    echo LOCALAPPDATA=%LOCALAPPDATA%
    echo APPDATA=%APPDATA%
    echo PATH=%PATH%
    echo.
    echo Tool discovery:
    where powershell.exe
    where cmd.exe
    where codex 2^>nul
    echo.
    echo Registry - Directory shell:
    reg query "HKCU\Software\Classes\Directory\shell\NCTDeveloperTools" /s 2^>nul
    echo.
    echo Registry - Directory background shell:
    reg query "HKCU\Software\Classes\Directory\Background\shell\NCTDeveloperTools" /s 2^>nul
    echo.
    echo Installed helpers:
    dir "%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu\helpers" /a 2^>nul
) > "%LOG_FILE%" 2>&1

echo Diagnostics saved to:
echo   %LOG_FILE%
echo.
pause

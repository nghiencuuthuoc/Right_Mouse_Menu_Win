@echo off
title NCT_Developer_Tools_Context_Menu_v3_Installer
setlocal EnableExtensions

set "APP_NAME=NCT Developer Tools Context Menu"
set "APP_VERSION=v3.0"
set "INSTALL_DIR=%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu"
set "SOURCE_DIR=%~dp0"
set "HELPERS_SOURCE=%SOURCE_DIR%helpers"
set "HELPERS_DIR=%INSTALL_DIR%\helpers"
set "PARENT_KEY=NCTDeveloperTools"

echo ============================================================
echo %APP_NAME% %APP_VERSION% - Installer
echo ============================================================
echo.

if not exist "%HELPERS_SOURCE%\open_codex_here.cmd" (
    echo ERROR: helpers folder was not found next to this installer.
    echo Expected: %HELPERS_SOURCE%
    echo.
    pause
    exit /b 1
)

echo Installing helper scripts to:
echo   %INSTALL_DIR%
echo.

mkdir "%HELPERS_DIR%" >nul 2>&1
copy /y "%HELPERS_SOURCE%\*.*" "%HELPERS_DIR%\" >nul
if errorlevel 1 (
    echo ERROR: Failed to copy helper scripts.
    pause
    exit /b 1
)

echo Removing old or broken context menu registrations...
call :CleanOldKeys

echo Adding cascading context menu entries...
call :AddCascadeRoot "Directory\shell" "%PARENT_KEY%"
call :AddSubCommand "Directory\shell" "%PARENT_KEY%" "OpenCodex" "Open Codex" "powershell.exe" "%HELPERS_DIR%\open_codex_here.cmd"
call :AddSubCommand "Directory\shell" "%PARENT_KEY%" "OpenCommandPrompt" "Open Command Prompt" "cmd.exe" "%HELPERS_DIR%\open_command_prompt_here.cmd"
call :AddSubCommand "Directory\shell" "%PARENT_KEY%" "OpenPowerShell" "Open PowerShell" "powershell.exe" "%HELPERS_DIR%\open_powershell_here.cmd"

call :AddCascadeRoot "Directory\Background\shell" "%PARENT_KEY%"
call :AddSubCommand "Directory\Background\shell" "%PARENT_KEY%" "OpenCodex" "Open Codex" "powershell.exe" "%HELPERS_DIR%\open_codex_here.cmd"
call :AddSubCommand "Directory\Background\shell" "%PARENT_KEY%" "OpenCommandPrompt" "Open Command Prompt" "cmd.exe" "%HELPERS_DIR%\open_command_prompt_here.cmd"
call :AddSubCommand "Directory\Background\shell" "%PARENT_KEY%" "OpenPowerShell" "Open PowerShell" "powershell.exe" "%HELPERS_DIR%\open_powershell_here.cmd"

echo.
echo Installation completed.
echo Right-click a folder or empty folder background, then open:
echo   Open Developer Tools
echo.
echo If the menu does not refresh, run restart_explorer__optional.bat.
echo On Windows 11, classic registry menu items may appear under Show more options.
echo.
pause
exit /b 0

:AddCascadeRoot
set "ROOT=%~1"
set "PARENT=%~2"
reg add "HKCU\Software\Classes\%ROOT%\%PARENT%" /v "MUIVerb" /d "Open Developer Tools" /f >nul
reg add "HKCU\Software\Classes\%ROOT%\%PARENT%" /v "Icon" /d "cmd.exe" /f >nul
reg add "HKCU\Software\Classes\%ROOT%\%PARENT%" /v "Position" /d "Top" /f >nul
reg add "HKCU\Software\Classes\%ROOT%\%PARENT%" /v "SubCommands" /d "" /f >nul
exit /b 0

:AddSubCommand
set "ROOT=%~1"
set "PARENT=%~2"
set "VERB=%~3"
set "LABEL=%~4"
set "ICON=%~5"
set "HELPER=%~6"
reg add "HKCU\Software\Classes\%ROOT%\%PARENT%\shell\%VERB%" /v "MUIVerb" /d "%LABEL%" /f >nul
reg add "HKCU\Software\Classes\%ROOT%\%PARENT%\shell\%VERB%" /v "Icon" /d "%ICON%" /f >nul
reg add "HKCU\Software\Classes\%ROOT%\%PARENT%\shell\%VERB%\command" /ve /d "\"%HELPER%\" \"%%V\" \"%%1\"" /f >nul
exit /b 0

:CleanOldKeys
for %%R in ("Directory\shell" "Directory\Background\shell") do (
    reg delete "HKCU\Software\Classes\%%~R\NCTDeveloperTools" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_DeveloperTools" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCTDeveloperToolsV2" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCTDeveloperToolsV3" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCodexHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCmdHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCommandPromptHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenPowerShellHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenPowershellHere" /f >nul 2>&1
)
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\NCT.OpenCodex" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\NCT.OpenCommandPrompt" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\NCT.OpenPowerShell" /f >nul 2>&1
exit /b 0

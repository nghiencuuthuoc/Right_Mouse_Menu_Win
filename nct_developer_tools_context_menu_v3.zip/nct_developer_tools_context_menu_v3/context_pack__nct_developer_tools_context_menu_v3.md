# Developer Context Pack - nct_developer_tools_context_menu_v3

## App goal

Add a compact Windows Explorer right-click submenu for folders:

```text
Open Developer Tools
    Open Codex
    Open Command Prompt
    Open PowerShell
```

The menu must work for both selected folders and empty folder background.

## User issue that v3 fixes

v2 produced this error when selecting Open Codex or Open PowerShell:

```text
Set-Location : Cannot bind argument to parameter 'LiteralPath' because it is null.
...
The term '<folder path>' is not recognized as the name of a cmdlet...
```

Root cause: the helper used inline `powershell.exe -Command` with `$args[0]`. On the user's machine, the folder argument was not bound correctly and was instead appended as executable PowerShell text.

## Main design change

v3 uses `.cmd` wrappers plus `.ps1` scripts:

```bat
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -NoExit -File "open_codex_here.ps1" -Target "<folder>"
```

The PowerShell script has:

```powershell
param([string]$Target)
Set-Location -LiteralPath $resolvedTarget
```

This avoids `$args[0]`, avoids inline script quoting bugs, and makes the selected path explicit.

## File structure

```text
install__nct_developer_tools_context_menu_v3.bat
uninstall__nct_developer_tools_context_menu_v3.bat
repair__nct_developer_tools_context_menu_v3.bat
verify__nct_developer_tools_context_menu_v3.bat
diagnose__nct_developer_tools_context_menu_v3.bat
backup_registry__nct_developer_tools_context_menu_v3.bat
restart_explorer__optional.bat
check_codex_path__nct_developer_tools_context_menu_v3.bat
helpers/open_codex_here.cmd
helpers/open_codex_here.ps1
helpers/open_command_prompt_here.cmd
helpers/open_powershell_here.cmd
helpers/open_powershell_here.ps1
helpers/resolve_target_folder.cmd
docs/registry_layout_v3.txt
docs/troubleshooting.md
docs/design_notes.md
readme__nct_developer_tools_context_menu_v3.md
context_pack__nct_developer_tools_context_menu_v3.md
package_manifest.txt
checksums_sha256.txt
```

## Registry layout

Per-user root:

```text
HKCU\Software\Classes
```

Selected folder:

```text
HKCU\Software\Classes\Directory\shell\NCTDeveloperTools
```

Folder background:

```text
HKCU\Software\Classes\Directory\Background\shell\NCTDeveloperTools
```

Cascade parent values:

```text
MUIVerb = Open Developer Tools
Icon = cmd.exe
Position = Top
SubCommands = ""
```

Local child verbs:

```text
shell\OpenCodex\command
shell\OpenCommandPrompt\command
shell\OpenPowerShell\command
```

Each command passes both Explorer placeholders:

```text
"<helper.cmd>" "%V" "%1"
```

## Dependencies

No Python dependency. No admin rights required.

System tools used:

- `reg.exe`
- `cmd.exe`
- `powershell.exe`
- Optional: `codex` CLI in PATH

## Input/output

Input: Explorer-selected folder path or current folder background path.

Output:

- Opens Command Prompt, PowerShell, or Codex from that folder.
- If Codex is missing, PowerShell remains open in the correct target folder and shows diagnostic guidance.

## Maintenance notes

- Avoid inline `powershell.exe -Command` for folder paths.
- Keep all batch comments/messages in English.
- Keep using HKCU unless a machine-wide install is explicitly required.
- If adding more tools, add new subcommands under the local `shell` subtree.
- If creating a new ZIP, include README, context pack, and checksums.

## Suggested future prompt

"Upgrade nct_developer_tools_context_menu_v3 by adding Git Bash, Windows Terminal, VS Code, and a settings file to enable/disable submenu items, while preserving HKCU per-user install and robust PowerShell -File argument passing."

@echo off
title NCT_Developer_Tools_Context_Menu_v4_Repair
setlocal EnableExtensions

echo Repairing NCT Developer Tools Context Menu v4...
echo This will remove old v1/v2/v3/v4 registry keys and reinstall v4.
echo.
call "%~dp0uninstall__nct_developer_tools_context_menu_v4.bat" /silent
call "%~dp0install__nct_developer_tools_context_menu_v4.bat"
exit /b %ERRORLEVEL%

@echo off
title Open_Codex_Here
setlocal EnableExtensions
set "TARGET=%~1"
if not defined TARGET set "TARGET=%CD%"

if not exist "%TARGET%" (
    echo Target folder does not exist:
    echo   %TARGET%
    echo.
    echo Falling back to current folder:
    echo   %CD%
    set "TARGET=%CD%"
)

for %%I in ("%TARGET%") do set "TARGET=%%~fI"

echo Opening Codex in:
echo   %TARGET%
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0open_codex_here.ps1" -Target "%TARGET%"

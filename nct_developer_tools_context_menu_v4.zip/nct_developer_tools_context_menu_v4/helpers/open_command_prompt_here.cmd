@echo off
title Open_Command_Prompt_Here
setlocal EnableExtensions
set "TARGET=%~1"
if not defined TARGET set "TARGET=%CD%"

if not exist "%TARGET%" (
    echo Target folder does not exist:
    echo   %TARGET%
    echo.
    echo Falling back to current folder:
    echo   %CD%
    set "TARGET=%CD%"
)

for %%I in ("%TARGET%") do set "TARGET=%%~fI"
echo Opening Command Prompt in:
echo   %TARGET%
echo.
cmd.exe /d /k pushd "%TARGET%"

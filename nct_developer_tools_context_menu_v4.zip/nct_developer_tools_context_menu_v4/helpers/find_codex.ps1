$ErrorActionPreference = "Continue"

function Add-Candidate {
    param(
        [System.Collections.Generic.List[string]]$List,
        [string]$Path
    )
    if ($Path) {
        $List.Add($Path)
    }
}

$candidates = New-Object System.Collections.Generic.List[string]

Add-Candidate -List $candidates -Path $env:CODEX_EXE

$local = $env:LOCALAPPDATA
if ($local) {
    Add-Candidate -List $candidates -Path (Join-Path $local "OpenAI\Codex\bin\codex.exe")

    $openAICodexBin = Join-Path $local "OpenAI\Codex\bin"
    if (Test-Path -LiteralPath $openAICodexBin) {
        Get-ChildItem -LiteralPath $openAICodexBin -Filter "codex.exe" -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
            Add-Candidate -List $candidates -Path $_.FullName
        }
    }

    $packageRoot = Join-Path $local "Packages"
    if (Test-Path -LiteralPath $packageRoot) {
        Get-ChildItem -LiteralPath $packageRoot -Directory -Filter "OpenAI.Codex_*" -ErrorAction SilentlyContinue | ForEach-Object {
            Add-Candidate -List $candidates -Path (Join-Path $_.FullName "LocalCache\Local\OpenAI\Codex\bin\codex.exe")
        }
    }
}

$cmd = Get-Command codex -ErrorAction SilentlyContinue
if ($cmd -and $cmd.Source) {
    Add-Candidate -List $candidates -Path $cmd.Source
}

$found = $candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique

Write-Host "Codex discovery result:"
if ($found) {
    $i = 1
    foreach ($item in $found) {
        Write-Host ("  {0}. {1}" -f $i, $item)
        $i++
    }
    Write-Host ""
    Write-Host "Selected executable:"
    Write-Host "  $($found | Select-Object -First 1)"
}
else {
    Write-Host "  Not found" -ForegroundColor Red
}

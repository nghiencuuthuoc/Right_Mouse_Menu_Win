param(
    [Parameter(Mandatory = $false)]
    [string]$Target
)

if ([string]::IsNullOrWhiteSpace($Target)) {
    $Target = (Get-Location).Path
}

try {
    $resolved = (Resolve-Path -LiteralPath $Target -ErrorAction Stop).ProviderPath
}
catch {
    Write-Host "Target folder was not found:" -ForegroundColor Yellow
    Write-Host "  $Target" -ForegroundColor Yellow
    $resolved = (Get-Location).Path
}

Set-Location -LiteralPath $resolved
Write-Host "Current folder is set to:"
Write-Host "  $resolved"
Write-Host ""

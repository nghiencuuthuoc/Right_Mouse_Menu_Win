param(
    [Parameter(Mandatory = $false)]
    [string]$Target
)

$ErrorActionPreference = "Continue"

function Resolve-TargetFolder {
    param([string]$InputPath)

    if ([string]::IsNullOrWhiteSpace($InputPath)) {
        return (Get-Location).Path
    }

    try {
        return (Resolve-Path -LiteralPath $InputPath -ErrorAction Stop).ProviderPath
    }
    catch {
        Write-Host "Target folder was not found:" -ForegroundColor Yellow
        Write-Host "  $InputPath" -ForegroundColor Yellow
        Write-Host "Falling back to current folder:"
        return (Get-Location).Path
    }
}

function Find-CodexExecutable {
    $candidates = New-Object System.Collections.Generic.List[string]

    if ($env:CODEX_EXE) {
        $candidates.Add($env:CODEX_EXE)
    }

    $local = $env:LOCALAPPDATA
    if ($local) {
        $candidates.Add((Join-Path $local "OpenAI\Codex\bin\codex.exe"))

        $packageRoot = Join-Path $local "Packages"
        if (Test-Path -LiteralPath $packageRoot) {
            Get-ChildItem -LiteralPath $packageRoot -Directory -Filter "OpenAI.Codex_*" -ErrorAction SilentlyContinue | ForEach-Object {
                $candidates.Add((Join-Path $_.FullName "LocalCache\Local\OpenAI\Codex\bin\codex.exe"))
            }
        }

        $openAICodexBin = Join-Path $local "OpenAI\Codex\bin"
        if (Test-Path -LiteralPath $openAICodexBin) {
            Get-ChildItem -LiteralPath $openAICodexBin -Filter "codex.exe" -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                $candidates.Add($_.FullName)
            }
        }
    }

    $cmd = Get-Command codex -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) {
        $candidates.Add($cmd.Source)
    }

    $unique = $candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
    return $unique | Select-Object -First 1
}

$targetFolder = Resolve-TargetFolder -InputPath $Target
Set-Location -LiteralPath $targetFolder

Write-Host "Codex target folder:"
Write-Host "  $targetFolder"
Write-Host ""

$codexExe = Find-CodexExecutable

if (-not $codexExe) {
    Write-Host "Codex CLI executable was not found." -ForegroundColor Red
    Write-Host ""
    Write-Host "Checked common locations:"
    Write-Host "  %LOCALAPPDATA%\OpenAI\Codex\bin\codex.exe"
    Write-Host "  %LOCALAPPDATA%\OpenAI\Codex\bin\*\codex.exe"
    Write-Host "  %LOCALAPPDATA%\Packages\OpenAI.Codex_*\LocalCache\Local\OpenAI\Codex\bin\codex.exe"
    Write-Host "  PATH command: codex"
    Write-Host ""
    Write-Host "You can also set CODEX_EXE to the full codex.exe path."
    return
}

Write-Host "Using Codex CLI:"
Write-Host "  $codexExe"
Write-Host ""

& $codexExe

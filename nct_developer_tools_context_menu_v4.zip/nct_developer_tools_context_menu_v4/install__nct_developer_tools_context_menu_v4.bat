@echo off
title NCT_Developer_Tools_Context_Menu_v4_Installer
setlocal EnableExtensions

set "APP_NAME=nct_developer_tools_context_menu_v4"
set "SRC_DIR=%~dp0"
set "APP_DIR=%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu_v4"
set "HELPERS_DIR=%APP_DIR%\helpers"

echo ============================================================
echo NCT Developer Tools Context Menu v4 - Installer
echo Adds a compact submenu:
echo   Open Developer Tools
echo     Open Codex
echo     Open Command Prompt
echo     Open PowerShell
echo ============================================================
echo.

if not exist "%APP_DIR%" mkdir "%APP_DIR%" >nul 2>&1
if not exist "%HELPERS_DIR%" mkdir "%HELPERS_DIR%" >nul 2>&1

xcopy "%SRC_DIR%helpers\*" "%HELPERS_DIR%\" /E /I /Y >nul
if errorlevel 1 (
    echo Failed to copy helper files.
    echo Source: "%SRC_DIR%helpers"
    echo Target: "%HELPERS_DIR%"
    pause
    exit /b 1
)

call :CleanOldKeys

call :AddParent "Directory\shell" "cmd.exe"
call :AddParent "Directory\Background\shell" "cmd.exe"
call :AddParent "Drive\shell" "cmd.exe"

call :AddItems "Directory\shell" "%%1"
call :AddItems "Directory\Background\shell" "%%V"
call :AddItems "Drive\shell" "%%1"

echo.
echo Installation completed.
echo.
echo Right-click a folder, folder background, or drive and open:
echo   Open Developer Tools
echo.
echo If File Explorer still shows old items, run restart_explorer__optional.bat.
echo.
pause
exit /b 0

:AddParent
set "ROOT=%~1"
set "ICON=%~2"
set "PARENT=HKCU\Software\Classes\%ROOT%\NCT_OpenDeveloperTools"
reg add "%PARENT%" /ve /d "Open Developer Tools" /f >nul
reg add "%PARENT%" /v "MUIVerb" /d "Open Developer Tools" /f >nul
reg add "%PARENT%" /v "Icon" /d "%ICON%" /f >nul
reg add "%PARENT%" /v "Position" /d "Top" /f >nul
reg add "%PARENT%" /v "SubCommands" /d "" /f >nul
exit /b 0

:AddItems
set "ROOT=%~1"
set "ARG=%~2"
set "BASE=HKCU\Software\Classes\%ROOT%\NCT_OpenDeveloperTools\shell"

reg add "%BASE%\01_OpenCodex" /ve /d "Open Codex" /f >nul
reg add "%BASE%\01_OpenCodex" /v "MUIVerb" /d "Open Codex" /f >nul
reg add "%BASE%\01_OpenCodex" /v "Icon" /d "powershell.exe" /f >nul
reg add "%BASE%\01_OpenCodex\command" /ve /d "\"%HELPERS_DIR%\open_codex_here.cmd\" \"%ARG%\"" /f >nul

reg add "%BASE%\02_OpenCommandPrompt" /ve /d "Open Command Prompt" /f >nul
reg add "%BASE%\02_OpenCommandPrompt" /v "MUIVerb" /d "Open Command Prompt" /f >nul
reg add "%BASE%\02_OpenCommandPrompt" /v "Icon" /d "cmd.exe" /f >nul
reg add "%BASE%\02_OpenCommandPrompt\command" /ve /d "\"%HELPERS_DIR%\open_command_prompt_here.cmd\" \"%ARG%\"" /f >nul

reg add "%BASE%\03_OpenPowerShell" /ve /d "Open PowerShell" /f >nul
reg add "%BASE%\03_OpenPowerShell" /v "MUIVerb" /d "Open PowerShell" /f >nul
reg add "%BASE%\03_OpenPowerShell" /v "Icon" /d "powershell.exe" /f >nul
reg add "%BASE%\03_OpenPowerShell\command" /ve /d "\"%HELPERS_DIR%\open_powershell_here.cmd\" \"%ARG%\"" /f >nul
exit /b 0

:CleanOldKeys
for %%R in ("Directory\shell" "Directory\Background\shell" "Drive\shell") do (
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenDeveloperTools" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCodexHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCmdHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenPowerShellHere" /f >nul 2>&1
)
reg delete "HKCU\Software\Classes\NCTDeveloperTools" /f >nul 2>&1
exit /b 0

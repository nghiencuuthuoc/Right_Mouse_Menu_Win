@echo off
title NCT_Developer_Tools_Context_Menu_v4_Registry_Backup
setlocal EnableExtensions

set "OUT_DIR=%~dp0registry_backup"
if not exist "%OUT_DIR%" mkdir "%OUT_DIR%" >nul 2>&1

reg export "HKCU\Software\Classes\Directory\shell\NCT_OpenDeveloperTools" "%OUT_DIR%\Directory_shell_NCT_OpenDeveloperTools.reg" /y >nul 2>&1
reg export "HKCU\Software\Classes\Directory\Background\shell\NCT_OpenDeveloperTools" "%OUT_DIR%\Directory_Background_shell_NCT_OpenDeveloperTools.reg" /y >nul 2>&1
reg export "HKCU\Software\Classes\Drive\shell\NCT_OpenDeveloperTools" "%OUT_DIR%\Drive_shell_NCT_OpenDeveloperTools.reg" /y >nul 2>&1

echo Registry backup folder:
echo   %OUT_DIR%
echo.
pause

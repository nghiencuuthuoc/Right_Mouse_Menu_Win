@echo off
title Check_Codex_Path_v4
setlocal EnableExtensions
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0helpers\find_codex.ps1"
echo.
echo Also checking with cmd where:
where codex 2>nul
if errorlevel 1 echo codex was not found by where codex.
echo.
pause

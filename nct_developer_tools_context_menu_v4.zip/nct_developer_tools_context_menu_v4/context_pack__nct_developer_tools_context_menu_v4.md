# Developer Context Pack - NCT Developer Tools Context Menu v4

## Goal

Create a robust per-user Windows Explorer context-menu submenu for developer tools:

```text
Open Developer Tools
    Open Codex
    Open Command Prompt
    Open PowerShell
```

The package is intended for the user's Windows dev environment under PharmApp/Right_Menu_Win.

## Important user-reported problems from previous versions

### v2 problem

PowerShell inline command used `$args[0]`, but the target folder was not bound to `$args[0]`. The folder path was interpreted as another command token.

Fix introduced in v3: use `.ps1` helpers with explicit `-Target` parameters.

### v3 problem

Codex was not found in `PATH`, even though `codex.exe` existed in these locations:

```text
C:\Users\NCT\AppData\Local\OpenAI\Codex\bin\fb2111b91430cb17\codex.exe
C:\Users\NCT\AppData\Local\OpenAI\Codex\bin\codex.exe
C:\Users\NCT\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Local\OpenAI\Codex\bin\codex.exe
```

Also, the menu sometimes opened in the package/helper folder instead of the clicked folder.

Fix introduced in v4:

- Auto-discover Codex executable in OpenAI local install locations.
- Use selected-folder placeholder `%1` for `Directory\shell` and `Drive\shell`.
- Use `%V` only for `Directory\Background\shell`.

## File structure

```text
install__nct_developer_tools_context_menu_v4.bat
repair__nct_developer_tools_context_menu_v4.bat
uninstall__nct_developer_tools_context_menu_v4.bat
verify__nct_developer_tools_context_menu_v4.bat
diagnose__nct_developer_tools_context_menu_v4.bat
backup_registry__nct_developer_tools_context_menu_v4.bat
restart_explorer__optional.bat
check_codex_path__nct_developer_tools_context_menu_v4.bat
helpers/
  open_codex_here.cmd
  open_codex_here.ps1
  open_command_prompt_here.cmd
  open_powershell_here.cmd
  open_powershell_here.ps1
  find_codex.ps1
docs/
  registry_layout_v4.txt
  troubleshooting.md
readme__nct_developer_tools_context_menu_v4.md
context_pack__nct_developer_tools_context_menu_v4.md
package_manifest.txt
checksums_sha256.txt
```

## Registry design

Per-user installation under:

```text
HKCU\Software\Classes
```

Parent keys:

```text
Directory\shell\NCT_OpenDeveloperTools
Directory\Background\shell\NCT_OpenDeveloperTools
Drive\shell\NCT_OpenDeveloperTools
```

Parent values:

```text
Default     = Open Developer Tools
MUIVerb     = Open Developer Tools
Icon        = cmd.exe
Position    = Top
SubCommands = empty string
```

Submenu local subtree:

```text
shell\01_OpenCodex\command
shell\02_OpenCommandPrompt\command
shell\03_OpenPowerShell\command
```

Command placeholders:

```text
Directory\shell command target             = "%1"
Directory\Background\shell command target = "%V"
Drive\shell command target                 = "%1"
```

## Codex discovery logic

`helpers/open_codex_here.ps1` and `helpers/find_codex.ps1` search in this priority order:

1. Environment variable `CODEX_EXE`
2. `%LOCALAPPDATA%\OpenAI\Codex\bin\codex.exe`
3. `%LOCALAPPDATA%\Packages\OpenAI.Codex_*\LocalCache\Local\OpenAI\Codex\bin\codex.exe`
4. Recursive `%LOCALAPPDATA%\OpenAI\Codex\bin\*\codex.exe`
5. `Get-Command codex`

The first existing executable is selected and started with PowerShell call operator `&`.

## Maintenance notes

- Keep batch and PowerShell messages in English.
- Keep console titles explicit.
- Avoid inline `powershell.exe -Command` with complex quoting.
- Prefer `powershell.exe -File script.ps1 -Target "..."`.
- Use HKCU, not HKLM, unless machine-wide install is explicitly required.
- If the package ever includes Python files, add `requirements.txt`.

## Suggested future developer prompt

Update the Windows Explorer context menu package `nct_developer_tools_context_menu_v4` while preserving the registry design. Keep per-user HKCU installation, maintain the submenu `Open Developer Tools`, preserve the `%1` and `%V` placeholder split, and keep Codex auto-discovery across OpenAI local install paths. Add new developer tools only as additional local submenu items under the parent key.

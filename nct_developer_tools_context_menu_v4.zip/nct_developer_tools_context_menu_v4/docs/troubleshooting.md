# Troubleshooting - NCT Developer Tools Context Menu v4

## 1. Open Codex says Codex was not found

v4 searches these locations automatically:

```text
%LOCALAPPDATA%\OpenAI\Codex\bin\codex.exe
%LOCALAPPDATA%\OpenAI\Codex\bin\*\codex.exe
%LOCALAPPDATA%\Packages\OpenAI.Codex_*\LocalCache\Local\OpenAI\Codex\bin\codex.exe
PATH command: codex
```

Run:

```bat
check_codex_path__nct_developer_tools_context_menu_v4.bat
```

You may also set a machine/user environment variable named `CODEX_EXE` to the full path of `codex.exe`.

## 2. Menu opens in the helper folder instead of the clicked folder

Run:

```bat
repair__nct_developer_tools_context_menu_v4.bat
restart_explorer__optional.bat
```

v4 fixes the placeholder mapping:

```text
Selected folder: %1
Folder background: %V
Drive: %1
```

## 3. Old broken menu remains visible

Run the uninstaller first:

```bat
uninstall__nct_developer_tools_context_menu_v4.bat
```

Then install again:

```bat
install__nct_developer_tools_context_menu_v4.bat
```

Restart Explorer if needed.

## 4. Windows 11 menu location

Classic registry context-menu entries may appear under **Show more options** depending on the Windows 11 build and shell configuration.

@echo off
title NCT_Developer_Tools_Context_Menu_v4_Diagnose
setlocal EnableExtensions

echo ============================================================
echo NCT Developer Tools Context Menu v4 Diagnosis
echo ============================================================
echo.

echo Current folder:
echo   %CD%
echo.

echo Package folder:
echo   %~dp0
echo.

echo Installed helper folder:
echo   %LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu_v4\helpers
echo.

echo Testing helper scripts with current package folder as target...
echo.
call "%~dp0helpers\open_command_prompt_here.cmd" "%~dp0"

echo.
echo Codex discovery:
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0helpers\find_codex.ps1"
echo.

echo Registry query:
reg query "HKCU\Software\Classes\Directory\shell\NCT_OpenDeveloperTools" /s

echo.
pause

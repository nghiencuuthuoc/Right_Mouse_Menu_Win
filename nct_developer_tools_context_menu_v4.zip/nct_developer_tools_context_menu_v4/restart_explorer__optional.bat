@echo off
title Restart_File_Explorer_Optional
setlocal EnableExtensions

echo This will restart Windows Explorer.
echo Open folders may close and reopen.
echo.
choice /C YN /M "Restart Explorer now"
if errorlevel 2 exit /b 0

taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe

echo Explorer restarted.
timeout /t 2 >nul
exit /b 0

# NCT Developer Tools Context Menu v4

This package adds a compact Windows Explorer context-menu submenu:

```text
Open Developer Tools
    Open Codex
    Open Command Prompt
    Open PowerShell
```

It works when you right-click:

- A selected folder
- The empty background inside a folder
- A drive

## Why v4 exists

v3 fixed the PowerShell `$args[0]` problem, but two issues remained on the target machine:

1. `codex.exe` existed but was not in `PATH`.
2. The selected folder context sometimes resolved to the helper/package folder instead of the folder that was clicked.

v4 fixes both:

- It auto-discovers Codex in OpenAI local install paths.
- It uses `%1` for selected folders and `%V` only for folder background context.
- It uses `.ps1` helper scripts with explicit `-Target` parameters.

## Install

Run:

```bat
install__nct_developer_tools_context_menu_v4.bat
```

If you installed an older version, run:

```bat
repair__nct_developer_tools_context_menu_v4.bat
```

Then optionally run:

```bat
restart_explorer__optional.bat
```

## Check Codex

Run:

```bat
check_codex_path__nct_developer_tools_context_menu_v4.bat
```

Expected Codex locations include:

```text
%LOCALAPPDATA%\OpenAI\Codex\bin\codex.exe
%LOCALAPPDATA%\OpenAI\Codex\bin\*\codex.exe
%LOCALAPPDATA%\Packages\OpenAI.Codex_*\LocalCache\Local\OpenAI\Codex\bin\codex.exe
```

For the provided user machine, known examples include:

```text
C:\Users\NCT\AppData\Local\OpenAI\Codex\bin\codex.exe
C:\Users\NCT\AppData\Local\OpenAI\Codex\bin\fb2111b91430cb17\codex.exe
C:\Users\NCT\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Local\OpenAI\Codex\bin\codex.exe
```

## Uninstall

Run:

```bat
uninstall__nct_developer_tools_context_menu_v4.bat
```

## Installed location

Helpers are copied to:

```text
%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu_v4\helpers
```

Registry keys are installed under:

```text
HKCU\Software\Classes
```

This keeps the installation per-user and avoids requiring administrator permission.

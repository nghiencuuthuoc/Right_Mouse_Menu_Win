@echo off
title NCT_Developer_Tools_Context_Menu_v4_Verify
setlocal EnableExtensions

echo ============================================================
echo Registry entries
echo ============================================================
echo.
reg query "HKCU\Software\Classes\Directory\shell\NCT_OpenDeveloperTools" /s
reg query "HKCU\Software\Classes\Directory\Background\shell\NCT_OpenDeveloperTools" /s
reg query "HKCU\Software\Classes\Drive\shell\NCT_OpenDeveloperTools" /s

echo.
echo ============================================================
echo Codex discovery
echo ============================================================
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0helpers\find_codex.ps1"
echo.
pause

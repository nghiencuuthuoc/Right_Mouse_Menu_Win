@echo off
title NCT_Developer_Tools_Context_Menu_v4_Uninstaller
setlocal EnableExtensions

set "APP_DIR=%LOCALAPPDATA%\NCT_Developer_Tools_Context_Menu_v4"

for %%R in ("Directory\shell" "Directory\Background\shell" "Drive\shell") do (
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenDeveloperTools" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCodexHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenCmdHere" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\%%~R\NCT_OpenPowerShellHere" /f >nul 2>&1
)
reg delete "HKCU\Software\Classes\NCTDeveloperTools" /f >nul 2>&1

if exist "%APP_DIR%" rmdir /s /q "%APP_DIR%" >nul 2>&1

if /I "%~1"=="/silent" exit /b 0

echo Uninstall completed.
echo If File Explorer still shows old items, run restart_explorer__optional.bat.
echo.
pause
exit /b 0
